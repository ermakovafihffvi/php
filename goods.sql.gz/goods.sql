-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3309
-- Время создания: Авг 07 2021 г., 20:08
-- Версия сервера: 5.6.51-log
-- Версия PHP: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `goods`
--

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `id` int(11) NOT NULL,
  `title` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) DEFAULT NULL,
  `photo` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `info` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id`, `title`, `price`, `photo`, `info`) VALUES
(1, 'Notebook', 300, 'notebook.jpg', 'This multipurpose hardbound notebook is made from unique PU cover and has hi-quality 80 gsm off-white paper. It’s enticing features include functional pocket inside, bookmark and a eleastic pen holder.\r\n\r\nSpecifications:\r\n- 80 gsm paper\r\n- 192 pages\r\n- Size: 18.6 cm x 27 cm\r\n- Colour: Brown'),
(2, 'Dairy', 289, 'dairy.jpg', 'Carry this corporate folder to your office. The black leather cover has a soft touch and makes it easy to carry anywhere. It is partitioned in five sections to arrange your work systematically. There is also a pen holder with pen at end . Rubber string acts as a lock and keeps all loose sheets and important documents in position.\r\n\r\nSpecifications:\r\n- Dimension : 22.3 cm x 18.5 cm\r\n- Colour: Black'),
(5, 'Planner', 102, 'planner.jpg', 'To plan your projects and finances this black leather planner is quite comfortable. It\'s magnetic lock with silver tag gives it good presentation. Ring binders helps to maintain the separators as per need. There are different sections for account, finance, diary and address. Pen holder at back helps to keep you from losing the pen without thinking of losing it. Card holders as well as space to carry your ID card is perfect package.\r\n\r\nSpecifications:\r\nDimensions: 24 x 19.4 cm');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `goods`
--
ALTER TABLE `goods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
